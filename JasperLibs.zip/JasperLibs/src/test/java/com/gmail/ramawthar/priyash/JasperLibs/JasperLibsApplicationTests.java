package com.gmail.ramawthar.priyash.JasperLibs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasperLibsApplicationTests {

	@Test
	void contextLoads() {
	}

}
